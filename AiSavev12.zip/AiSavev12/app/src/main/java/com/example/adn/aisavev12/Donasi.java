package com.example.adn.aisavev12;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;

public class Donasi extends AppCompatActivity {
    EditText donatur;
    EditText alamat;
    EditText telp;
    EditText tglkirim;
    EditText qty;
    RadioButton alatbersih;
    RadioButton obat;
    RadioButton makan;
    Button next;

    String jenis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donasi);

        donatur =(EditText) findViewById(R.id.donatur);
        alamat =(EditText) findViewById(R.id.alamat);
        telp =(EditText) findViewById(R.id.telp);
        tglkirim =(EditText) findViewById(R.id.tglkirim);
        qty =(EditText) findViewById(R.id.qty);
        alatbersih =(RadioButton) findViewById(R.id.alatbersih);
        obat=(RadioButton) findViewById(R.id.obat);
        makan=(RadioButton) findViewById(R.id.makan);
        next=(Button) findViewById(R.id.next);

        alatbersih.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    jenis = "Alat-alat kebersihan";
                }
            }
        });

        obat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    jenis = "Obat-obatan";

                }
            }
        });

        makan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    jenis = "Makanan";
                }
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent j = new Intent(getApplicationContext(),Konfirsmasi.class);
                j.putExtra("nama",donatur.getText().toString());
                j.putExtra("addr",alamat.getText().toString());
                j.putExtra("telp",telp.getText().toString());
                j.putExtra("tgl",tglkirim.getText().toString());
                j.putExtra("qty",qty.getText().toString());
                j.putExtra("jenis",jenis);

                startActivity(j);

            }
        });


    }
}
