package com.example.adn.aisavev12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Konfirsmasi extends AppCompatActivity {

    TextView kNama;
    TextView alamat;
    TextView telp;
    TextView tglKrm;
    TextView jBrg;
    TextView jml;
    Button confirm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_konfirsmasi);

        kNama = (TextView) findViewById(R.id.kNama);
        alamat = (TextView) findViewById(R.id.alamat);
        telp = (TextView) findViewById(R.id.telp);
        tglKrm = (TextView) findViewById(R.id.tglKrm);
        jBrg = (TextView) findViewById(R.id.jBrg);
        jml = (TextView) findViewById(R.id.jml);
        confirm = (Button) findViewById(R.id.confirm);

        Bundle j = getIntent().getExtras();
        String nama2 = j.getString("nama");
        String  alamat2 = j.getString("addr");
        String telp2 = j.getString("telp");
        String tgl = j.getString("tgl");
        String qty = j.getString("qty");
        String jenis = j.getString("jenis");


        kNama.setText(String.valueOf(nama2));
        alamat.setText(String.valueOf(alamat2));
        telp.setText(String.valueOf(telp2));
        tglKrm.setText(String.valueOf(tgl));
        jBrg.setText(String.valueOf(jenis));
        jml.setText(String.valueOf(qty));
    }
}
